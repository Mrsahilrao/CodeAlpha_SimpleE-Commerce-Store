from decimal import Decimal
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm
from .models import Product, Order, OrderItem
from .forms import RegisterForm

def _get_cart(request):
    return request.session.get('cart', {})

def _save_cart(request, cart):
    request.session['cart'] = cart
    request.session.modified = True

def index(request):
    products = Product.objects.all()
    return render(request, 'index.html', {'products': products})

def product_detail(request, pk):
    product = get_object_or_404(Product, pk=pk)
    return render(request, 'product_detail.html', {'product': product})

def add_to_cart(request, pk):
    product = get_object_or_404(Product, pk=pk)
    cart = _get_cart(request)
    qty = int(request.POST.get('quantity', 1))
    cart[str(product.id)] = cart.get(str(product.id), 0) + qty
    _save_cart(request, cart)
    messages.success(request, f'Added {qty} x {product.name} to cart.')
    return redirect('cart')

def remove_from_cart(request, pk):
    cart = _get_cart(request)
    cart.pop(str(pk), None)
    _save_cart(request, cart)
    messages.info(request, 'Item removed from cart.')
    return redirect('cart')

def cart_view(request):
    cart = _get_cart(request)
    items = []
    total = Decimal('0.00')
    for product_id, quantity in cart.items():
        product = get_object_or_404(Product, pk=product_id)
        qty = int(quantity)
        line_total = product.price * qty
        items.append({'product': product, 'quantity': qty, 'line_total': line_total})
        total += line_total
    return render(request, 'cart.html', {'items': items, 'total': total})

@login_required
def checkout(request):
    cart = _get_cart(request)
    if not cart:
        messages.error(request, 'Your cart is empty.')
        return redirect('cart')

    items = []
    total = Decimal('0.00')
    for product_id, quantity in cart.items():
        product = get_object_or_404(Product, pk=product_id)
        qty = int(quantity)
        line_total = product.price * qty
        items.append((product, qty, product.price))
        total += line_total

    if request.method == 'POST':
        order = Order.objects.create(user=request.user, total_amount=total, status='PENDING')
        for product, qty, price in items:
            OrderItem.objects.create(order=order, product=product, quantity=qty, price_each=price)
        _save_cart(request, {})
        messages.success(request, f'Order #{order.id} placed successfully!')
        return redirect('orders')

    return render(request, 'checkout.html', {'items': items, 'total': total})

@login_required
def order_list(request):
    orders = Order.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'orders.html', {'orders': orders})

def register_view(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Registration successful.')
            return redirect('index')
    else:
        form = RegisterForm()
    return render(request, 'register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            messages.success(request, 'Logged in successfully.')
            return redirect('index')
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})

def logout_view(request):
    logout(request)
    messages.info(request, 'Logged out.')
    return redirect('index')
